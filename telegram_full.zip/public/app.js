
let me = null;
let ws = null;
let peer = null;

async function reg(){
    let name = document.getElementById("name").value;
    let r = await fetch("/api/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name})});
    let j = await r.json();
    me = j.id;
    document.getElementById("myid").innerText = me;

    ws = new WebSocket("ws://localhost:3000");
    ws.onopen = ()=> ws.send(JSON.stringify({type:"auth", id:me}));
    ws.onmessage = e => handle(JSON.parse(e.data));
}

async function addContact(){
    let contactId = document.getElementById("contact").value;
    await fetch("/api/addContact",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({userId:me, contactId})});
    let li = document.createElement("li");
    li.innerText = contactId;
    document.getElementById("clist").appendChild(li);
}

function sendMsg(){
    ws.send(JSON.stringify({
        type:"msg",
        text:document.getElementById("msg").value,
        to:selected()
    }));
}

function selected(){
    let list=document.getElementById("clist");
    return list.children[0]?.innerText || null;
}

function handle(d){
    if(d.type==="msg"){
        document.getElementById("chatbox").innerHTML += `<div><b>${d.from}:</b> ${d.text}</div>`;
    }
    if(d.type==="offer") rtcAccept(d);
    if(d.type==="answer") peer.setRemoteDescription(new RTCSessionDescription(d.answer));
    if(d.type==="candidate") peer.addIceCandidate(new RTCIceCandidate(d.cand));
}

async function prepareCall(video=false){
    peer = new RTCPeerConnection();
    peer.onicecandidate = e=>{
        if(e.candidate) ws.send(JSON.stringify({type:"candidate", to:selected(), cand:e.candidate}));
    };
    peer.ontrack = e=>{
        document.getElementById("remote").srcObject = e.streams[0];
    };

    let stream = await navigator.mediaDevices.getUserMedia(video?{video:true,audio:true}:{audio:true});
    document.getElementById("local").srcObject = stream;

    stream.getTracks().forEach(t=>peer.addTrack(t,stream));
}

async function call(){
    await prepareCall(false);
    let offer = await peer.createOffer();
    await peer.setLocalDescription(offer);
    ws.send(JSON.stringify({type:"offer", to:selected(), offer}));
}

async function vcall(){
    await prepareCall(true);
    let offer = await peer.createOffer();
    await peer.setLocalDescription(offer);
    ws.send(JSON.stringify({type:"offer", to:selected(), offer}));
}

async function rtcAccept(d){
    await prepareCall(!!d.offer.video);
    await peer.setRemoteDescription(new RTCSessionDescription(d.offer));
    let ans = await peer.createAnswer();
    await peer.setLocalDescription(ans);
    ws.send(JSON.stringify({type:"answer", to:d.from, answer:ans}));
}
