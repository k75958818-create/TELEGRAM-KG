
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.json());
app.use(express.static('public'));

let users = {};     // id -> {name}
let contacts = {};  // id -> [contactIds]
let sockets = {};   // id -> ws

// register
app.post('/api/register', (req, res) => {
    const name = req.body.name || "User";
    const id = Date.now().toString();
    users[id] = { name };
    contacts[id] = [];
    res.json({ id, name });
});

// add contact
app.post('/api/addContact', (req, res) => {
    const { userId, contactId } = req.body;
    if (users[userId] && users[contactId]) {
        contacts[userId].push(contactId);
        res.json({ ok: true });
    } else res.json({ ok: false });
});

// WebSocket
wss.on('connection', ws => {
    let uid = null;

    ws.on('message', msg => {
        let data;
        try { data = JSON.parse(msg); } catch { return; }

        if (data.type === "auth") {
            uid = data.id;
            sockets[uid] = ws;
            return;
        }

        if (data.to && sockets[data.to]) {
            sockets[data.to].send(JSON.stringify(data));
        }
    });

    ws.on('close', () => {
        if (uid) delete sockets[uid];
    });
});

server.listen(3000, () => console.log("SERVER RUN http://localhost:3000"));
